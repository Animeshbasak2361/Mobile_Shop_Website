<?php
ob_start();
//include header.php file
include('header.php');
?>

<?php
/* include cart templete section*/
include('Template/_cart-template.php')
?>

<?php
/* include cart templete section*/
include('Template/_wishlist_template.php')
?>



<?php
/* include new phone section*/
include('Template/_new-phones.php')
?>




<?php
//include footer.php file
include('footer.php');
?>
