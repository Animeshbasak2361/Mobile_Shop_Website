<?php
//include header.php file
include('header.php');
?>

<?php
    /* include product.php section*/
    include('Template/_products.php')
?>


<?php
/* include top sale section*/
include('Template/_top-sale.php')
?>




<?php
//include footer.php file
include('footer.php');
?>
